@echo off
rd /s /q "%LOCALAPPDATA%\HydroExamMonitor"
del "%USERPROFILE%\Desktop\Hydro OJ 监考系统.lnk"
echo 已卸载。
pause
